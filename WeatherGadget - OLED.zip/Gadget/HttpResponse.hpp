#if !defined(GADGET_HTTPRESPONSE_HPP)
#define GADGET_HTTPRESPONSE_HPP

#include <Arduino.h>
#include <WiFi.h>

class HttpResponse {

public:

    HttpResponse() {
        
    }

};

#endif // GADGET_HTTPRESPONSE_HPP
