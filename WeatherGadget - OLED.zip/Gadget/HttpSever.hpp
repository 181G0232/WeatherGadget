#if !defined(GADGET_SERVER_HPP)
#define GADGET_HTTPSERVER_HPP

#include <Arduino.h>

class HttpServer {

public:

    HttpServer() {
        
    }

};

#endif // GADGET_HTTPSERVER_HPP
