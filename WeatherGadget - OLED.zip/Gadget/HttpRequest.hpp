#if !defined(GADGET_HTTPREQUEST_HPP)
#define GADGET_HTTPREQUEST_HPP

#include <Arduino.h>
#include <WiFi.h>

class HtttpRequest {

public:

    HtttpRequest() {

    }

};

#endif // GADGET_HTTPREQUEST_HPP
